# ConformalLadder — Stage 1 summary tables

## Table 1 — Pilot 0: B3LYP/6-31G(2df,p) → G4MP2 on QM9 (130 258 molecules), one lumped layer

90 % intervals (α = 0.10); certification = |corrected error| < 1 kcal/mol at FDR q = 0.10.

| scenario                   |   n_train |   n_cal |   n_test |   MAE_raw |   MAE_corrected |   coverage_split |   coverage_CQR |   weighted_abstain |   coverage_weighted_answered |   BH_certified |   BH_FDP |   naive_certified |   naive_FDP |
|:---------------------------|----------:|--------:|---------:|----------:|----------------:|-----------------:|---------------:|-------------------:|-----------------------------:|---------------:|---------:|------------------:|------------:|
| A_random                   |     78154 |   26052 |    26052 |     4.422 |           0.740 |            0.903 |          0.900 |              0.000 |                        0.903 |          0.145 |    0.106 |             0.043 |       0.056 |
| B1_soft_size_shift         |     22829 |    9784 |    20000 |     4.497 |           0.885 |            0.890 |          0.878 |              0.000 |                        0.885 |          0.000 |    0.000 |             0.005 |       0.215 |
| B2_hard_size_extrapolation |     15175 |    6504 |    20000 |     4.507 |           1.892 |            0.417 |          0.617 |              1.000 |                      nan     |          0.000 |    0.000 |             0.061 |       0.580 |
| C_element_shift_F          |     60000 |   20000 |     1908 |    12.848 |           5.843 |            0.004 |          0.008 |              1.000 |                      nan     |          0.000 |    0.000 |             0.039 |       1.000 |

## Table 1b — Pilot 0: empirical FDP versus nominal q (exchangeable split)

|     q |   fraction_selected |   FDP |   power |
|------:|--------------------:|------:|--------:|
| 0.010 |               0.000 | 0.000 |   0.000 |
| 0.020 |               0.000 | 0.000 |   0.000 |
| 0.050 |               0.031 | 0.048 |   0.041 |
| 0.100 |               0.145 | 0.106 |   0.178 |
| 0.200 |               0.610 | 0.198 |   0.672 |
| 0.300 |               1.000 | 0.271 |   1.000 |

## Table 2 — Pilot 1: four-layer ladder on MultiXC-QM9 isomerization energies (21468 pairs; PBE/DZP → TZP → B3LYP(VWN5) → -D → G4MP2)

| split                         |   n_train |   n_cal |   n_test |   eps_total_MAE_raw |   eps_total_MAE_model |   eps_total_coverage |   beta_basis_MAE_raw |   beta_basis_MAE_model |   beta_basis_coverage |   phi_functional_MAE_raw |   phi_functional_MAE_model |   phi_functional_coverage |   delta_dispersion_MAE_raw |   delta_dispersion_MAE_model |   delta_dispersion_coverage |   rho_remainder_MAE_raw |   rho_remainder_MAE_model |   rho_remainder_coverage |   I_bf_MAE_raw |   I_bf_MAE_model |   I_bf_coverage |   BH_certified |   BH_FDP |   BH_gate_certified |   naive_certified |   naive_FDP |
|:------------------------------|----------:|--------:|---------:|--------------------:|----------------------:|---------------------:|---------------------:|-----------------------:|----------------------:|-------------------------:|---------------------------:|--------------------------:|---------------------------:|-----------------------------:|----------------------------:|------------------------:|--------------------------:|-------------------------:|---------------:|-----------------:|----------------:|---------------:|---------:|--------------------:|------------------:|------------:|
| A_formula_grouped_random      |     10915 |    4832 |     5721 |               2.704 |                 0.891 |                0.895 |                1.300 |                  0.568 |                 0.896 |                    3.350 |                      0.453 |                     0.905 |                      1.014 |                        0.382 |                       0.914 |                   2.162 |                     0.679 |                    0.918 |          0.141 |            0.050 |           0.898 |          0.275 |    0.111 |               0.275 |             0.137 |       0.056 |
| B_size_extrapolation_le8_to_9 |      7604 |    3518 |    10346 |               2.753 |                 1.108 |                0.858 |                1.306 |                  0.626 |                 0.841 |                    3.030 |                      0.603 |                     0.837 |                      1.094 |                        0.462 |                       0.830 |                   2.168 |                     0.865 |                    0.848 |          0.141 |            0.061 |           0.875 |          0.184 |    0.120 |               0.000 |             0.156 |       0.107 |
| C_element_shift_noF_to_F      |     12798 |    5192 |     3478 |               1.717 |                 0.753 |                0.917 |                0.876 |                  0.475 |                 0.906 |                    1.411 |                      0.323 |                     0.936 |                      0.538 |                        0.275 |                       0.888 |                   0.982 |                     0.543 |                    0.920 |          0.066 |            0.040 |           0.951 |          0.235 |    0.080 |               0.000 |             0.057 |       0.066 |

## Table 2b — Pilot 1: measured layer budget by molecule size (MAE, kcal/mol)

| subset    |     n |   eps_total_MAE |   beta_basis_MAE |   phi_functional_MAE |   delta_dispersion_MAE |   rho_remainder_MAE |   I_bf_MAE |
|:----------|------:|----------------:|-----------------:|---------------------:|-----------------------:|--------------------:|-----------:|
| n_heavy=3 |     2 |           1.639 |            0.899 |                1.901 |                  0.098 |               1.830 |      0.090 |
| n_heavy=4 |    18 |           1.310 |            1.019 |                1.320 |                  0.370 |               1.245 |      0.056 |
| n_heavy=5 |   321 |           2.235 |            1.004 |                2.548 |                  0.568 |               1.479 |      0.093 |
| n_heavy=6 |  1470 |           2.344 |            1.110 |                3.007 |                  0.765 |               1.855 |      0.122 |
| n_heavy=7 |  3354 |           2.593 |            1.181 |                3.118 |                  0.862 |               1.971 |      0.132 |
| n_heavy=8 |  5957 |           2.636 |            1.224 |                3.137 |                  0.989 |               2.127 |      0.135 |
| n_heavy=9 | 10346 |           2.753 |            1.306 |                3.030 |                  1.094 |               2.168 |      0.141 |
| ALL       | 21468 |           2.658 |            1.245 |                3.063 |                  0.998 |               2.093 |      0.136 |

## Table 3 — Pilot 2: correlation × basis non-additivity on the QM7b grid (MP2/6-31G → MP2/cc-pVDZ → CCSD(T)/cc-pVDZ)

I_bc = [CCSD(T)−MP2]_cc-pVDZ − [CCSD(T)−MP2]_6-31G is the exact error of the additive composite scheme.

| problem       | split                   |   n_train |   n_cal |   n_test |   eps_total_MAE_raw |   eps_total_MAE_model |   eps_total_coverage |   beta_basis_MAE_raw |   beta_basis_MAE_model |   beta_basis_coverage |   kappa_correlation_MAE_raw |   kappa_correlation_MAE_model |   kappa_correlation_coverage |   I_bc_MAE_raw |   I_bc_MAE_model |   I_bc_coverage |   composite_within1_raw |   composite_within1_learned |   abstain |   cert_gate_frac |   cert_gate_FDP |   cert_nogate_frac |   cert_nogate_FDP |   naive_frac |   naive_FDP |
|:--------------|:------------------------|----------:|--------:|---------:|--------------------:|----------------------:|---------------------:|---------------------:|-----------------------:|----------------------:|----------------------------:|------------------------------:|-----------------------------:|---------------:|-----------------:|----------------:|------------------------:|----------------------------:|----------:|-----------------:|----------------:|-------------------:|------------------:|-------------:|------------:|
| atomization   | A_random                |      3605 |    1803 |     1803 |             104.747 |                 1.586 |                0.891 |              132.342 |                  1.696 |                 0.895 |                      27.596 |                         0.562 |                        0.921 |         21.635 |            0.251 |           0.908 |                   0.000 |                       0.967 |     0.000 |            1.000 |           0.033 |              1.000 |             0.033 |        0.864 |       0.013 |
| atomization   | B_element_shift_to_S_Cl |      4811 |    2063 |      337 |             125.473 |                32.411 |                0.169 |              161.204 |                 31.609 |                 0.270 |                      35.731 |                         2.518 |                        0.537 |         25.970 |            1.760 |           0.315 |                   0.000 |                       0.202 |     0.994 |            0.006 |           1.000 |              1.000 |             0.798 |        0.368 |       0.863 |
| atomization   | C_size_shift_le6_to_7   |       819 |     351 |     6041 |             107.523 |                10.445 |                0.761 |              136.399 |                 11.767 |                 0.548 |                      28.876 |                         6.858 |                        0.059 |         22.400 |            3.802 |           0.066 |                   0.000 |                       0.035 |     1.000 |            0.000 |           0.000 |              1.000 |             0.965 |        0.632 |       0.969 |
| isomerization | A_formula_grouped       |      3855 |    1611 |     1959 |               5.291 |                 1.370 |                0.893 |                5.388 |                  1.347 |                 0.910 |                       1.473 |                         0.610 |                        0.913 |          1.092 |            0.327 |           0.908 |                   0.639 |                       0.925 |     0.000 |            1.000 |           0.075 |              1.000 |             0.075 |        0.686 |       0.016 |
| isomerization | B_element_shift_to_S_Cl |      4625 |    1830 |      970 |               4.415 |                 2.618 |                0.765 |                4.683 |                  3.295 |                 0.627 |                       0.971 |                         0.894 |                        0.867 |          0.806 |            0.428 |           0.855 |                   0.694 |                       0.914 |     1.000 |            0.000 |           0.000 |              0.993 |             0.079 |        0.710 |       0.025 |

## Table 3b — Pilot 2: raw size of each layer (kcal/mol) before any learning

| problem       |   eps_total_MAE |   eps_total_mean |   eps_total_P95_abs |   beta_basis_MAE |   beta_basis_mean |   beta_basis_P95_abs |   kappa_correlation_MAE |   kappa_correlation_mean |   kappa_correlation_P95_abs |   I_bc_MAE |   I_bc_mean |   I_bc_P95_abs |
|:--------------|----------------:|-----------------:|--------------------:|-----------------:|------------------:|---------------------:|------------------------:|-------------------------:|----------------------------:|-----------:|------------:|---------------:|
| atomization   |         104.472 |         -104.472 |             134.031 |          132.198 |          -132.198 |              155.037 |                  27.727 |                   27.726 |                      39.996 |     21.635 |      21.635 |         26.172 |
| isomerization |           5.246 |            1.929 |              15.478 |            5.447 |             2.079 |               16.050 |                   1.514 |                   -0.150 |                       4.220 |      1.149 |      -0.265 |          3.930 |

## Table 4 — Abstention gates under distribution shift (certificate at q = 0.10)

| scenario                       | gate                 |   answered |   coverage_answered |   certified |   FDP |   power |
|:-------------------------------|:---------------------|-----------:|--------------------:|------------:|------:|--------:|
| P1 iso: formula-grouped random | none                 |      1.000 |               0.889 |       0.168 | 0.087 |   0.239 |
| P1 iso: formula-grouped random | weighted_conformal   |      1.000 |               0.889 |       0.168 | 0.087 |   0.239 |
| P1 iso: formula-grouped random | knn_support          |      0.985 |               0.889 |       0.168 | 0.087 |   0.240 |
| P1 iso: formula-grouped random | conditional_coverage |      0.931 |               0.892 |       0.130 | 0.071 |   0.189 |
| P1 iso: formula-grouped random | knn_and_conditional  |      0.916 |               0.892 |       0.133 | 0.072 |   0.192 |
| P1 iso: size ≤8 → 9            | none                 |      1.000 |               0.848 |       0.147 | 0.111 |   0.225 |
| P1 iso: size ≤8 → 9            | weighted_conformal   |      0.000 |             nan     |       0.000 | 0.000 |   0.000 |
| P1 iso: size ≤8 → 9            | knn_support          |      0.928 |               0.850 |       0.146 | 0.106 |   0.226 |
| P1 iso: size ≤8 → 9            | conditional_coverage |      0.905 |               0.858 |       0.114 | 0.096 |   0.178 |
| P1 iso: size ≤8 → 9            | knn_and_conditional  |      0.838 |               0.860 |       0.122 | 0.098 |   0.191 |
| P1 iso: no F → F               | none                 |      1.000 |               0.930 |       0.000 | 0.000 |   0.000 |
| P1 iso: no F → F               | weighted_conformal   |      0.000 |             nan     |       0.000 | 0.000 |   0.000 |
| P1 iso: no F → F               | knn_support          |      0.966 |               0.928 |       0.004 | 0.000 |   0.005 |
| P1 iso: no F → F               | conditional_coverage |      0.952 |               0.931 |       0.004 | 0.000 |   0.005 |
| P1 iso: no F → F               | knn_and_conditional  |      0.918 |               0.929 |       0.004 | 0.000 |   0.005 |
| P2 AE: random                  | none                 |      1.000 |               0.906 |       1.000 | 0.044 |   1.000 |
| P2 AE: random                  | weighted_conformal   |      1.000 |               0.906 |       1.000 | 0.044 |   1.000 |
| P2 AE: random                  | knn_support          |      0.985 |               0.907 |       0.985 | 0.042 |   0.988 |
| P2 AE: random                  | conditional_coverage |      0.896 |               0.924 |       0.896 | 0.040 |   0.900 |
| P2 AE: random                  | knn_and_conditional  |      0.884 |               0.923 |       0.884 | 0.038 |   0.890 |
| P2 AE: → S/Cl                  | none                 |      1.000 |               0.359 |       1.000 | 0.825 |   1.000 |
| P2 AE: → S/Cl                  | weighted_conformal   |      0.009 |               1.000 |       0.009 | 0.667 |   0.017 |
| P2 AE: → S/Cl                  | knn_support          |      0.531 |               0.251 |       0.531 | 0.849 |   0.458 |
| P2 AE: → S/Cl                  | conditional_coverage |      0.902 |               0.398 |       0.902 | 0.809 |   0.983 |
| P2 AE: → S/Cl                  | knn_and_conditional  |      0.445 |               0.300 |       0.445 | 0.827 |   0.441 |
| P2 AE: size ≤6 → 7             | none                 |      1.000 |               0.055 |       1.000 | 0.972 |   1.000 |
| P2 AE: size ≤6 → 7             | weighted_conformal   |      0.000 |             nan     |       0.000 | 0.000 |   0.000 |
| P2 AE: size ≤6 → 7             | knn_support          |      0.970 |               0.054 |       0.970 | 0.971 |   1.000 |
| P2 AE: size ≤6 → 7             | conditional_coverage |      0.976 |               0.056 |       0.976 | 0.972 |   0.982 |
| P2 AE: size ≤6 → 7             | knn_and_conditional  |      0.947 |               0.055 |       0.947 | 0.971 |   0.982 |
| P2 ISO: formula-grouped        | none                 |      1.000 |               0.910 |       0.910 | 0.066 |   0.946 |
| P2 ISO: formula-grouped        | weighted_conformal   |      1.000 |               0.910 |       0.910 | 0.066 |   0.946 |
| P2 ISO: formula-grouped        | knn_support          |      0.981 |               0.909 |       0.900 | 0.064 |   0.937 |
| P2 ISO: formula-grouped        | conditional_coverage |      0.918 |               0.923 |       0.852 | 0.057 |   0.895 |
| P2 ISO: formula-grouped        | knn_and_conditional  |      0.902 |               0.922 |       0.842 | 0.055 |   0.886 |
| P2 ISO: → S/Cl                 | none                 |      1.000 |               0.869 |       1.000 | 0.063 |   1.000 |
| P2 ISO: → S/Cl                 | weighted_conformal   |      0.000 |             nan     |       0.000 | 0.000 |   0.000 |
| P2 ISO: → S/Cl                 | knn_support          |      0.818 |               0.887 |       0.818 | 0.045 |   0.833 |
| P2 ISO: → S/Cl                 | conditional_coverage |      0.832 |               0.879 |       0.832 | 0.063 |   0.832 |
| P2 ISO: → S/Cl                 | knn_and_conditional  |      0.680 |               0.897 |       0.680 | 0.041 |   0.696 |

## Table 5 — Escalate-to-recalibrate: coverage / width / FDP versus the number of escalated items

| scenario            | variant                     |   n_new |   coverage |   coverage_sd |   width |   MAE |   certified |   FDP |   FDP_max |
|:--------------------|:----------------------------|--------:|-----------:|--------------:|--------:|------:|------------:|------:|----------:|
| P1 iso: size ≤8 → 9 | calibrate_only              |      25 |      0.956 |         0.019 |   7.200 | 1.119 |       0.000 | 0.000 |     0.000 |
| P1 iso: size ≤8 → 9 | calibrate_only              |      50 |      0.904 |         0.059 |   5.818 | 1.119 |       0.171 | 0.099 |     0.298 |
| P1 iso: size ≤8 → 9 | calibrate_only              |     100 |      0.921 |         0.009 |   5.784 | 1.118 |       0.074 | 0.118 |     0.167 |
| P1 iso: size ≤8 → 9 | calibrate_only              |     200 |      0.911 |         0.014 |   5.565 | 1.118 |       0.051 | 0.039 |     0.118 |
| P1 iso: size ≤8 → 9 | calibrate_only              |     400 |      0.898 |         0.007 |   5.263 | 1.119 |       0.123 | 0.101 |     0.142 |
| P1 iso: size ≤8 → 9 | retrain_half_calibrate_half |     100 |      0.919 |         0.022 |   5.376 | 1.115 |       0.085 | 0.061 |     0.184 |
| P1 iso: size ≤8 → 9 | retrain_half_calibrate_half |     400 |      0.906 |         0.015 |   5.238 | 1.107 |       0.097 | 0.077 |     0.120 |
| P2 AE: size ≤6 → 7  | calibrate_only              |      25 |      0.969 |         0.014 | 922.831 | 3.609 |       0.000 | 0.000 |     0.000 |
| P2 AE: size ≤6 → 7  | calibrate_only              |      50 |      0.911 |         0.049 |  81.494 | 3.610 |       0.000 | 0.000 |     0.000 |
| P2 AE: size ≤6 → 7  | calibrate_only              |     100 |      0.890 |         0.018 |  37.783 | 3.608 |       0.000 | 0.000 |     0.000 |
| P2 AE: size ≤6 → 7  | calibrate_only              |     200 |      0.900 |         0.030 |  42.791 | 3.607 |       0.000 | 0.333 |     1.000 |
| P2 AE: size ≤6 → 7  | calibrate_only              |     400 |      0.905 |         0.017 |  42.773 | 3.610 |       0.000 | 0.333 |     1.000 |
| P2 AE: size ≤6 → 7  | retrain_half_calibrate_half |     100 |      0.896 |         0.033 |   4.654 | 0.969 |       0.000 | 0.000 |     0.000 |
| P2 AE: size ≤6 → 7  | retrain_half_calibrate_half |     400 |      0.904 |         0.021 |   3.447 | 0.619 |       0.008 | 0.089 |     0.267 |
| P2 AE: → S/Cl       | calibrate_only              |      25 |      0.897 |         0.031 |  13.304 | 1.851 |       0.000 | 0.000 |     0.000 |
| P2 AE: → S/Cl       | calibrate_only              |      50 |      0.912 |         0.087 |  18.908 | 1.843 |       0.000 | 0.000 |     0.000 |
| P2 AE: → S/Cl       | calibrate_only              |     100 |      0.882 |         0.044 |  12.378 | 1.837 |       0.001 | 0.333 |     1.000 |
| P2 AE: → S/Cl       | retrain_half_calibrate_half |     100 |      0.890 |         0.025 |   2.679 | 0.569 |       0.731 | 0.134 |     0.156 |
| P2 ISO: → S/Cl      | calibrate_only              |      25 |      0.928 |         0.058 |   2.457 | 0.373 |       0.588 | 0.035 |     0.059 |
| P2 ISO: → S/Cl      | calibrate_only              |      50 |      0.924 |         0.043 |   2.372 | 0.373 |       0.873 | 0.049 |     0.062 |
| P2 ISO: → S/Cl      | calibrate_only              |     100 |      0.911 |         0.021 |   2.134 | 0.376 |       1.000 | 0.065 |     0.067 |
| P2 ISO: → S/Cl      | calibrate_only              |     200 |      0.909 |         0.020 |   2.092 | 0.374 |       1.000 | 0.062 |     0.065 |
| P2 ISO: → S/Cl      | calibrate_only              |     400 |      0.914 |         0.014 |   2.085 | 0.367 |       1.000 | 0.059 |     0.068 |
| P2 ISO: → S/Cl      | retrain_half_calibrate_half |     100 |      0.903 |         0.052 |   2.166 | 0.345 |       1.000 | 0.057 |     0.063 |
| P2 ISO: → S/Cl      | retrain_half_calibrate_half |     400 |      0.924 |         0.015 |   1.537 | 0.264 |       1.000 | 0.025 |     0.037 |

## Table 6 — W4-17: layer budget for each choice of the DFT rung (MAE, kcal/mol; cheap level PBE/def2-SVP; W4 references)

| rung          |    n |   eps_cheap |   beta |    phi |   delta |   rho_after_ladder |   I_bf |   I_bf_gt1_pct |   I_fd |
|:--------------|-----:|------------:|-------:|-------:|--------:|-------------------:|-------:|---------------:|-------:|
| BLYP-D3BJ     | 1042 |      11.461 |  4.871 |  5.484 |   1.140 |              6.164 |  0.728 |         24.664 |  0.621 |
| TPSS-D3BJ     | 1042 |      11.461 |  4.871 |  6.557 |   0.655 |              5.443 |  0.498 |         10.845 |  0.137 |
| r2SCAN-D3BJ   | 1042 |      11.461 |  4.871 |  7.562 |   0.135 |              4.830 |  0.983 |         34.837 |  0.384 |
| B3LYP-D3BJ    | 1042 |      11.461 |  4.871 |  9.111 |   0.932 |              3.231 |  0.508 |         12.668 |  0.414 |
| PBE0-D3BJ     | 1042 |      11.461 |  4.871 |  8.628 |   0.446 |              4.246 |  0.853 |         30.230 |  0.074 |
| wB97X-D3BJ    | 1042 |      11.461 |  4.871 |  9.774 |   1.304 |              3.595 |  1.015 |         37.332 |  0.798 |
| M06-2X-D3ZERO | 1042 |      11.461 |  4.871 | 10.482 |   0.003 |              3.368 |  1.221 |         41.651 |  0.155 |

## Table 6b — W4-17: non-additivity and remainder by multireference status

| ('rung', '')   |   ('I_bf', 'MR') |   ('I_bf', 'nonMR') |   ('rho_after_ladder', 'MR') |   ('rho_after_ladder', 'nonMR') |
|:---------------|-----------------:|--------------------:|-----------------------------:|--------------------------------:|
| B3LYP-D3BJ     |            0.464 |               0.519 |                        3.341 |                           3.203 |
| BLYP-D3BJ      |            0.681 |               0.740 |                        8.549 |                           5.569 |
| M06-2X-D3ZERO  |            1.049 |               1.264 |                        5.750 |                           2.774 |
| PBE0-D3BJ      |            0.864 |               0.850 |                        3.619 |                           4.402 |
| TPSS-D3BJ      |            0.335 |               0.539 |                        6.962 |                           5.065 |
| r2SCAN-D3BJ    |            0.808 |               1.027 |                        5.115 |                           4.759 |
| wB97X-D3BJ     |            0.968 |               1.026 |                        3.986 |                           3.497 |

## Table 7 — W4-17: learned layers with conformal intervals (rung M06-2X-D3ZERO; n_train 417, n_cal 208, n_test 209, MR reactions 208)

| layer            |   MAE_raw |   MAE_model |   coverage |   mean_width |   MR_OOD_coverage |
|:-----------------|----------:|------------:|-----------:|-------------:|------------------:|
| eps_total        |    11.552 |       4.361 |      0.842 |       18.947 |             0.755 |
| beta_basis       |     5.028 |       2.571 |      0.880 |       13.267 |             0.856 |
| phi_functional   |     9.894 |       1.880 |      0.904 |       11.184 |             0.784 |
| delta_dispersion |     0.002 |       0.001 |      0.895 |        0.005 |             0.928 |
| rho_remainder    |     2.728 |       1.692 |      0.933 |        9.723 |             0.697 |
| I_bf             |     1.382 |       0.619 |      0.880 |        2.810 |             0.755 |

## Table 8 — W4-17: cheap diagnostics

|   n_functionals |   spearman_spread_svp_vs_abs_rho |   spearman_spread_svp_vs_abs_Ibf |   fod_auc_for_MR_membership_molecules |   fod_converged_fraction |
|----------------:|---------------------------------:|---------------------------------:|--------------------------------------:|-------------------------:|
|           8.000 |                            0.160 |                            0.289 |                                 0.799 |                    1.000 |
