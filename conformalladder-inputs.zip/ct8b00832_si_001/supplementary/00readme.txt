
Three computational methods are used: HF, MP2 and CCSD(T) 
(increasingly more expensive) combined with 3 basis sets: 
sto-3g, 6-31g and ccpvdz (increasingly larger). Overall, 
9 combinations are possible, as seen in the figure below; 
i.e., there are 9 calculations for each molecule.

    (basis set)
         ^
 ccpvdz  |  x             x               x
         |
         |
         |
  6-31G  |  x             x               x
         |
         |
         |
  sto-3g |  x             x               x
         ------------------------------------>
            HF            MP2           CCSD(T) 
                         (quantum chemistry method)

                        ------> more expensive

Regarding files:
1) Gemoetries are all stored as xyz files under the folder geometries/
2) Two types of txt data files are provided: 
   Etot_[*bst*].txt  --  total energies (E)
   E_[*bst*].txt     --  effective averaged atomization energies
                         (E_eff), defined as E - \sum_I n_I*e_I,
                         where n_I is the number of atom I in the
                         molecule and e_I is the effective atomic 
                         energy of atom I obtained throught a linear
                         fit of E = \sum_I n_I*e_I for all molecuels
                         in the dataset.
   * `bst stands for basis set

   Each of the above txt files contains 3 columns, 
   representing the three quantum chemistry methods with
   increasing complexity, i.e., HF, MP2 and CCSD(T).

   For nuclear repulsion energies, see file Enn.txt

   All energies are in kcal/mol.
3) nzs.txt contains the number of each element (including H,C,N,O.S,Cl
   with nuclear charges being respectively 1,6,7,8,16,17) in each molecule.
   There exists an 1-to-1 correspondence between the line number and the 
   geometry file with filename formatted as frag_xxxx.xyz in the folder 
   geometries/ in a sequential order.
4) in folder atoms/, all reference ground state atomic energies calculated 
   at the above-mentioned 9 different levels of theory are provided.

